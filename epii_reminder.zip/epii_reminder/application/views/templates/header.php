
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EPI Reminder</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/fontawesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/slick.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css">
</head>
<body>
    
    <header>
        <div class="header-area">
           <div class="container-fluid">
              <div class="row">
                 <div class="col-xl-3 d-flex align-items-center">
                  <div class="logo">
                    <a href="#"><img src="<?php echo base_url();?>assets/img/Child Care.png" alt=""></a>
                  </div>
                 </div>
                 <div class="col-xl-9">
                   <div class="main-menu float-right">
                     <nav>
                      <ul>
                          <li><a href="">Home</a></li>
                          <li><a href="">About Us</a></li>
                          <li><a href="">Birth Registration</a></li>
                          <li><a href="">EPI Vaccines</a></li>
                          <li><a href="">Services</a></li>
                          <li><a href="">Send Alert</a></li>
                          <li><a href="">Contact Us
                          </a></li>
                      </ul>
                     </nav>
                   </div>
                 </div>
              </div>
           </div>
        </div>
    </header>
