<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller
{
	public function index()
	{
        $this->load->view('templates/header');
        $this->load->view('home');
		$this->load->view('templates/footer');
		
	}
	public function feature()
	{
        $this->load->view('templates/header');
        $this->load->view('feature');
        $this->load->view('templates/footer');
		
	}
}
